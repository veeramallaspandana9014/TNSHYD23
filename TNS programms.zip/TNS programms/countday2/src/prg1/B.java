package prg1;

public class B {
	int a=10;//instance
	static int b=40;//static
	public static void main(String[] args) {
	int c=70;//local
	{
System.out.println(c);
B a1=new B();
System.out.println(a1.a);

	
		System.out.println(B.b);
	}
	
}
	}
