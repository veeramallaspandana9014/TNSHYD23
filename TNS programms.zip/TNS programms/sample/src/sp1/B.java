package sp1;

	import sp.*;
	public class B extends A{
	public static void main(String args[])
	{
		B obj=new B();
		obj.display();
		
	}
}
