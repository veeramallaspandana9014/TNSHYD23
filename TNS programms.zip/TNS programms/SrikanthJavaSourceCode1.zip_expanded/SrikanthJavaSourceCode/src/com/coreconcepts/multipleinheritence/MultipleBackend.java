package com.coreconcepts.multipleinheritence;

public interface MultipleBackend {
	
	//abstract method
	public void connectServer() ;

}
