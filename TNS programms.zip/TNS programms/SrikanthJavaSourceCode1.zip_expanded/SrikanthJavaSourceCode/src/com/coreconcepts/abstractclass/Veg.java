package com.coreconcepts.abstractclass;

public class Veg extends Person{
	
	@Override
	public void eat() {
		System.out.println("Eats veg");
	}

}
