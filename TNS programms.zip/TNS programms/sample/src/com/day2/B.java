package com.day2;

public class B {
 int a=10;
 static int b=20;
 int display() {
	 return 10;
 }
 static void display1() {
	 System.out.println(10);
 }

 public static void main(String args[]) {
	B b1=new B();
	System.out.println(b1.a);
	b1.display();
	System.out.println(B.b);
	B.display1();
 }
}


