package com.coreconcepts.accessmodifiers1;

import com.coreconcepts.accessmodifiers.*;

public class Protected2Main extends ProtectedA {
	
	public static void main(String[] args) {
		
		Protected2Main p3 = new Protected2Main();
		p3.display();
		
	}

}
