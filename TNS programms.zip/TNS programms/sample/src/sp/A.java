package sp;

public class A {
	protected void display ()
	{
		System.out.println("tns seesion");
	}

}
