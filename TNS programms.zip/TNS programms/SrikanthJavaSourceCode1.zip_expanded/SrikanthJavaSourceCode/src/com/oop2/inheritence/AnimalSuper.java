package com.oop2.inheritence;

public class AnimalSuper {
	
	
	public void eat() {
		System.out.println("I can eat");
	}

}
