package com.day3;

public class C {
	public static void main(String args[]) {
		D d1=new D();
		System.out.println(d1.a);
		d1.display();
		System.out.println(D.b);
		D.display1();
	 }
	}

