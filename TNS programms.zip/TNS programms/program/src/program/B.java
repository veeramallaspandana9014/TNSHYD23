package program;

public class B {

}
