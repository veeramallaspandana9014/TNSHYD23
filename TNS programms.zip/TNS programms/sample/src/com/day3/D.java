package com.day3;

public class D {
	int a=10;
	 static int b=20;
	 int display() {
		 return 10;
	 }
	 static void display1() {
		 System.out.println(10);
	 }
}
