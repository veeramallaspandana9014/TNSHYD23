package pp;

public class A {
	public void display()
	{
		System.out.println("tns seesions");
	}

}
