package car;

public class student {
private String name;
private String id;
private String dep;
public int marks;
}
