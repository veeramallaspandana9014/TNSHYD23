package com.coreconcepts.accessmodifiers1;

import com.coreconcepts.accessmodifiers.PublicA;

public class Public3Main {
	
	public static void main(String[] args) {
		
		PublicA p3 = new PublicA();
		p3.display();
		
	}

}
