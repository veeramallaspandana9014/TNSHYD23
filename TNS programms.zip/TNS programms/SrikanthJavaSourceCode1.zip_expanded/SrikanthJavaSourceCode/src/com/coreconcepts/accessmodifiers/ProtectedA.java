package com.coreconcepts.accessmodifiers;

public class ProtectedA {
	
	protected void display() {
		System.out.println("TNS Sessions");
	}

}
