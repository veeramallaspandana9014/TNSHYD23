package com.methods;

public class MethodwithParametersWithReturnType22 {
	
	public static void main(String[] args) {
		
		System.out.println("Area of Reactangle with length=5.4" + "and width =3.2");
		double area=areaReactangle(5.4,3.2);
		System.out.println(area);
		
	}

	public static double areaReactangle(double length, double width) {
		// TODO Auto-generated method stub
		return (length*width);
	}

}
