package program;

public class A {
	protected void display()
	{
		System.out.println("tns session");
	}
}

