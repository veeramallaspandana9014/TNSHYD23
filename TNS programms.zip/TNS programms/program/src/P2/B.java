package P2;

public class B {
	import p1.*
	public static void main(String[]args)
	{
		
	}
	

}
