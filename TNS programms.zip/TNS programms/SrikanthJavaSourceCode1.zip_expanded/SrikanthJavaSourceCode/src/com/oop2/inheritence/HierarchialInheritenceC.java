package com.oop2.inheritence;

public class HierarchialInheritenceC extends HierarchialInheritenceA{
	
	 public void show() {
		 System.out.println(" I am a method from class C");
	 }

}
