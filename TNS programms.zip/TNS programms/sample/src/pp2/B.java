package pp2;
import pp.*;
 class B {
	 public void main (String[]args)
	 {
		 A obj=new A();
		 obj.display();
	 
	 }
}
