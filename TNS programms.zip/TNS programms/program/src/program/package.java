package program;

public class B {
import program.*;
public class B extends A
{
	public static void main (string[]args)
	{
		B obj=new B();
		obj.display();
}

}
