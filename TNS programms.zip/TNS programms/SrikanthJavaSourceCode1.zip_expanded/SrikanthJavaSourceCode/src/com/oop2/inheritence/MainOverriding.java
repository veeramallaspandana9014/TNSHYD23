package com.oop2.inheritence;

public class MainOverriding {
	
	public static void main(String[] args) {
		
		DogMethodOverriding lab = new DogMethodOverriding();
		
		lab.eat();
		lab.bark();
		
	}

}
