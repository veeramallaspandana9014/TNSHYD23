package prg;

public class A {

	public static void main(String[] args) {
	System.out.println("this is my 1st program");

	}

}
