package com.coreconcepts.accessmodifiers1;

import com.coreconcepts.accessmodifiers.DefaultA;

public class Default2Main {
	
	public static void main(String[] args) {
		DefaultA a2 = new DefaultA();
		a2.diaplay();
	}

}
